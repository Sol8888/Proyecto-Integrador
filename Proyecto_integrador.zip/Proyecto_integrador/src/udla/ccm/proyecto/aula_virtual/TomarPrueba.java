package udla.ccm.proyecto.aula_virtual;

import java.util.Scanner;

public class TomarPrueba {

    private Matricula matricula;
    private Prueba prueba;
    private BancoPregunta bp;
    private Respuesta respuesta;
    private int version;

    public TomarPrueba(Prueba prueba, Matricula matricula, int version) {
        this.matricula = matricula;
        this.prueba = prueba;
        this.version = version;
        cargarPregunta();
    }

    private void cargarPregunta() {
        bp = prueba.asignarVersionRandom();
        int tamanio = bp.getListaPreguntas().size();

        Scanner scanner = new Scanner(System.in);

        for (int i = 0; i < tamanio; i++) {
            String pregunta = bp.obtenerPregunta(i).getEnunciado();
            System.out.println("Pregunta " + (i + 1) + ": " + pregunta);

            // Mostrar opciones de respuesta y obtener respuesta del usuario
            System.out.print("Ingrese la opción de respuesta (1-4): ");
            int respuestaUsuario = scanner.nextInt();

            // Almacenar la respuesta en el objeto 'respuesta'
            matricula.getAlumno().darUnaRespuesta(prueba.getNombre(), version).agregarRespuestaPosicion(
                    bp.obtenerPregunta(i).imprimirRespuesta(respuestaUsuario - 1), i);
        }

        // Resto de la lógica aquí
        float nota = matricula.getAlumno().darUnaRespuesta(prueba.getNombre(), version).calificarPrueba(bp);
        float notasobre10 = matricula.getAlumno().darUnaRespuesta(prueba.getNombre(), version).sobreDiez(nota);

        System.out.println("Calificación sobre puntaje prueba: " + nota);
        System.out.println("Calificación sobre diez: " + notasobre10);
    }

    public static void main(String[] args) {
        // Crea una instancia de Prueba y Matricula antes de llamar a TomarPruebaConsola
        Prueba prueba = new Prueba();  // Reemplaza con la creación real de tu objeto Prueba
        Matricula matricula = new Matricula();  // Reemplaza con la creación real de tu objeto Matricula
        int version = 1;  // Reemplaza con la versión real que necesites

        TomarPrueba tomarPruebaConsola = new TomarPrueba(prueba, matricula, version);
        // Resto de la lógica aquí
    }
}

