package udla.ccm.proyecto.aula_virtual;

import java.util.ArrayList;
import java.util.List;


public class BancoPregunta {
    private List<Pregunta> listaPreguntas;
    private int version;


    public BancoPregunta(int version){
        this.version = version;
        this.listaPreguntas = new ArrayList<Pregunta>();
    }

    public List<Pregunta> getListaPreguntas() {
        return listaPreguntas;
    }

    public void setListaPreguntas(List<Pregunta> listaPreguntas) {
        this.listaPreguntas = listaPreguntas;
    }

    public int getVersion() {
        return version;
    }

    public void setVersion(int version) {
        this.version = version;
    }


    public void anadirPregunta(Pregunta pregunta){
        listaPreguntas.add(pregunta);
    }

    public String [] imprimirPreguntas(int cont){
        //return fila;
        String fila[]={String.valueOf(cont+1),listaPreguntas.get(cont).getEnunciado()};
        return fila;
    }

    public Pregunta obtenerPregunta(int cont){
        return listaPreguntas.get(cont);
    }

}

