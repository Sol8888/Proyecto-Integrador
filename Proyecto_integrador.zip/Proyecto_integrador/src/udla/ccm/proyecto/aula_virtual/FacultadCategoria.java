package udla.ccm.proyecto.aula_virtual;
 public enum FacultadCategoria {
        POLITICAS,
        DERECHO,
        APLICADAS,
        MEDICINA,
        ODONTOLOGIA,

}
