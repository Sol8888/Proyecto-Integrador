package udla.ccm.proyecto.aula_virtual;

import java.util.ArrayList;
import java.util.List;

public class Clase{
    private String codigo;
    private String identificador;
    private Fecha creacion;
    private boolean estado;
    private Profesor profesor;
    private Materia materia;
    private static int contador=0000;
    private List<Prueba> pruebas;
    private List <Matricula> matriculas;

    public Clase(String identificador, Profesor profesor, Materia materia) {
        this.identificador = identificador;
        this.profesor = profesor;
        this.materia = materia;
        this.creacion= new Fecha();
        this.estado=true;
        matriculas= new ArrayList<Matricula>();
        pruebas=new ArrayList<Prueba>();
        this.codigo=identificador+"-"+String.valueOf(contador);
        contador++;
    }



    public static int getContador() {
        return contador;
    }

    public String getIdentificador() {
        return identificador;
    }

    public String getCodigo() {
        return codigo;
    }
    /**
     *
     * @param matricula Recibe un objeto matricula y añade a la lista de matriculas
     */
    public void agregarMatricula(Matricula matricula )
    {
        matriculas.add(matricula);
    }
    /**
     *
     * @param prueba Recibe un objeto prueba y añade a la lista de pruebas
     */
    public void agregarPrueba(Prueba prueba )
    {
        pruebas.add(prueba);
    }
    public Materia getMateria() {
        return materia;
    }
    /**
     *
     * @param alumno Recibe un objeto alumno
     * @return un booleano true para validación aceptada, false para validacion no acpetada
     */

    public boolean validarInscripcion(Alumno alumno){
        boolean v_facultad=materia.getFacultad().equals(alumno.getFacultad());
        boolean v_periodo=materia.getCarrera().equals(alumno.getCarrera());
        boolean v_carrera=materia.getPeriodo().equals(alumno.getPeriodo());
        System.out.println("Resultado"+v_facultad+v_carrera+v_periodo);
        return v_carrera&&v_facultad&&v_periodo;
    }

    public Profesor getProfesor() {
        return profesor;
    }

    public Fecha getCreacion() {
        return creacion;
    }

    public boolean isEstado() {
        return estado;
    }

    public List<Prueba> getPruebas() {
        return pruebas;
    }

    public List<Matricula> getMatriculas() {
        return matriculas;
    }

    /**
     *
     * @param cont recibe un entero que usa como indice de busqueda en lista de pruebas
     * @return un Arreglo tipo String con nombre de prueba, número de intentos,fecha limite, tiempo aproximado
     */
    public String [] imprimirPruebas(int cont){
        //return fila;
        String fila[]={pruebas.get(cont).getNombre(),String.valueOf(pruebas.get(cont).getIntentos()),String.valueOf(pruebas.get(cont).getFechaLimite()),String.valueOf(pruebas.get(cont).getTiempo())};
        return fila;
    }

    /**
     *
     * @param nombre recibe un string nombre
     * @return true para validar nombre unico correcto y false para valida un nombre unico no correcto
     */
    public boolean validarNombreUnico(String nombre){

        for(Prueba prueba:pruebas){
            if(prueba.getNombre().equals(nombre)){
                return false;
            }
        }
        return true;
    }

    /**
     *
     * @param nombre recibe un string nombre
     * @return un objeto prueba de la lista de pruebas con el nombre recibido en caso de coincido, si no null
     */

    public Prueba darUnaPrueba(String nombre){
        for(Prueba prueba:pruebas){
            if(prueba.getNombre().equals(nombre)){
                return prueba;
            }
        }
        return null;
    }
    /**
     *
     * @param alumnof recibe un objeto alumno
     * @return false cuando el alumno puede inscribirse, true cuando el alumno no puede inscribirse porque ya esta inscrito previamente
     */

    public boolean validarInscripcionUnica(Alumno alumnof){
        for(Matricula matricula:matriculas){
            if(matricula.getAlumno().getCedula().equals(alumnof.getCedula())){
                System.out.println("Ento a if");
                return true;
            }
            System.out.println("No entro");
        }
        return false;
    }
}

