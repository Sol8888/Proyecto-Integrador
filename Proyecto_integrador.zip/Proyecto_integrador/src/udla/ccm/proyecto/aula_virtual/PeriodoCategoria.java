package udla.ccm.proyecto.aula_virtual;

public enum PeriodoCategoria {
    PRIMERO,
    SEGUNDO,
    TERCER,
    CUARTO,
    QUINTO,
    SEXTO,
    SEPTIMO,
    OCTAVO,
    NOVENO,
    DECIMO,
}
