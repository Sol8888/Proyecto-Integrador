package udla.ccm.proyecto.aula_virtual;

import java.util.ArrayList;
import java.util.List;
public class Prueba {
    private String nombre;
    private String descripcion;
    private String ojetivos;
    private int versiones;
    private int tiempo;
    private int intentos;
    private Fecha fechaLimite;
    private List<BancoPregunta> bancopreguntas;


    public Prueba(String nombre, String descripcion, String ojetivos, int tiempo,int versiones,int intentos,Fecha fecha) {
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.ojetivos = ojetivos;
        this.versiones=versiones;
        this.tiempo=tiempo;
        this.intentos=intentos;
        this.bancopreguntas=new ArrayList<BancoPregunta>();
        crearBancoPregunta(versiones);
        this.fechaLimite=fecha;
        //preguntar si debo inicializar el banco preguntas
    }
    /**
     *
     * @param versiones recibe un entero, este se usa para crear los objetos Banco Pregunta
     */
    private void crearBancoPregunta (int versiones){
        for(int i=1;i<=versiones;i++){
            bancopreguntas.add(new BancoPregunta(i));
        }
    }

    /**
     *
     * @param version recibe un entero version
     * @return un objeo banco pregunta de la lista banco preguntas de dicha versión
     */
    public BancoPregunta darVersion( int version )
    {
        // for colección
        for (BancoPregunta bp:bancopreguntas){
            if (bp.getVersion()==version)
            {
                return bp;
            }
        }
        return null;
    }


    public List<BancoPregunta> getBancopreguntas() {
        return bancopreguntas;
    }

    /**
     *
     * @param version recibe un entero tipo version
     * @param pregunta recibe un objeto tipo pregunta
     */
    public void anadirPregunta(int version, Pregunta pregunta){
        BancoPregunta bancopregunta=darVersion(version);
        bancopregunta.anadirPregunta(pregunta);
    }

    public String getNombre() {
        return nombre;
    }

    public int getVersiones() {
        return versiones;
    }

    public int getIntentos() {
        return intentos;
    }

    public Fecha getFechaLimite() {
        return fechaLimite;
    }

    public int getTiempo() {
        return tiempo;
    }
    /**
     *
     * @return un bancopregunta random entre los bancos de pregunta existentes en la lista bancopreguntas
     */
    public BancoPregunta asignarVersionRandom(){
        int controlVersion,numero;
        controlVersion=versiones;
        numero = (int) (Math.random() * controlVersion) ;//PUEDE SER
        return bancopreguntas.get(numero);

    }

    public String getDescripcion() {
        return descripcion;
    }

    public String getOjetivos() {
        return ojetivos;
    }







}

