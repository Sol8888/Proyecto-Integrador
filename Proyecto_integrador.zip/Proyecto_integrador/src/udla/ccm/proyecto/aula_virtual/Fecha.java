package udla.ccm.proyecto.aula_virtual;
import java.util.Calendar;


/**
 *
 * @author Didier Guerrero
 */
public class Fecha {
    private int dia, mes, anio;

    public Fecha(int dia, int mes, int anio) {
        this.dia = dia;
        this.mes = mes;
        this.anio = anio;
    }
    public Fecha (){
        Calendar fecha1 = Calendar.getInstance();
        this.mes = fecha1.get(Calendar.MONTH)+1;
        this.dia=fecha1.get(Calendar.DATE);
        this.anio=fecha1.get(Calendar.YEAR);
    }

    public int obtenerDia() {
        return dia;
    }

    public int obtenerMes() {
        return mes;
    }

    public int obtenerAnio() {
        return anio;
    }

    /**
     *
     * @param fecha recibe un objeto tipo fecha
     * @return true si esta en el plazo la fecha, false si no esta dentro del plazo
     */
    public boolean validarFechaPruebaDar(Fecha fecha){//EL OBJETO  QUE LLAMA AL MÉTODO DEBER SER FECHA DEL SISTEMA CONTRUCTOR()

        if(this.anio<=fecha.obtenerAnio()){
            if(this.mes==fecha.obtenerMes()){
                if(this.dia<=fecha.obtenerDia()){
                    return true;
                }
                else{
                    return false;
                }
            }
            else if(this.mes<fecha.obtenerMes()){//Creo mal
                return true;
            }
            else{
                return false;
            }
        }
        return false;
    }



    @Override
    public String toString() {
        return dia + "/" + mes + "/" + anio ;
    }
}
