package udla.ccm.proyecto.aula_virtual;

import java.util.ArrayList;
import java.util.stream.Collectors;

public class MenuProfe {

    private Profesor profesor;

    public MenuProfe(Usuario usuario) {
        profesor = (Profesor) usuario;
        cargarMateriasConsola();
    }

    private void cargarMateriasConsola() {
        // USO FILTER
        int count = 0;
        ArrayList<Clase> datosClase = new ArrayList<>();
        datosClase = ConsolaLogin.clases.stream()
                .filter(clase -> clase.getProfesor().getCedula().equals(profesor.getCedula()))
                .collect(Collectors.toCollection(ArrayList::new));

        for (Clase clase : datosClase) {
            String estado = clase.isEstado() ? "ACTIVO" : "DESACTIVADO";
            System.out.printf("%s\t%s\t%s\t%s%n", clase.getIdentificador(), clase.getMateria().getNombreMat(),
                    estado, clase.getCreacion());
            count++;
        }
    }

    public static void main(String[] args) {
        // Aquí puedes cargar tus datos y crear una instancia de MenuProfeConsola
        // Datos.cargarDatos();
        // Usuario usuario = new Profesor("Ing", "123", "Marco", "lala");
        // new MenuProfeConsola(usuario);
    }
}
