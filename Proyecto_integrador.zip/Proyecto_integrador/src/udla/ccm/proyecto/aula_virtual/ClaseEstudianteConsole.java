package udla.ccm.proyecto.aula_virtual;

import java.util.Scanner;

public class ClaseEstudianteConsole {

    private Matricula matricula;

    public ClaseEstudianteConsole(Matricula matricula) {
        this.matricula = matricula;
    }

    private void cargarMateriasConsola() {
        int count = 0;
        System.out.println("Pruebas Activas:");
        System.out.printf("%-20s%-20s%-20s%-20s\n", "Nombre", "Cantidad Intentos", "Fecha Limite", "Tiempo Aproximado");

        int busqueda = matricula.getClase().getPruebas().size();
        for (int i = 0; i < busqueda; i++) {
            String[] fila = matricula.getClase().imprimirPruebas(i);
            System.out.printf("%-20s%-20s%-20s%-20s\n", fila[0], fila[1], fila[2], fila[3]);
            count++;
        }
    }

    private void manejarSeleccionPrueba() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("\nIngrese el nombre de la prueba que desea tomar: ");
        String nombrePrueba = scanner.nextLine();

        Prueba prueba = matricula.getClase().darUnaPrueba(nombrePrueba);

        if (prueba != null) {
            System.out.print("Ingrese su respuesta: ");
            String respuesta = scanner.nextLine();

            // Realizar lógica de evaluación de la respuesta y actualizar según sea necesario.
            // Aquí puedes implementar la lógica que harías en la versión con interfaz gráfica.

            System.out.println("¡Prueba completada!");
        } else {
            System.out.println("Prueba no encontrada.");
        }
    }

    public void ejecutar() {
        System.out.println("Bienvenido, " + this.matricula.getAlumno().getNombre() + ".");
        System.out.println("Pruebas disponibles para la clase " + this.matricula.getClase().getIdentificador() + ":");

        cargarMateriasConsola();
        manejarSeleccionPrueba();
    }


}

