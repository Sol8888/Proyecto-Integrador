package udla.ccm.proyecto.aula_virtual;

import java.util.ArrayList;
import java.util.List;

public class Alumno extends Usuario{
    private FacultadCategoria facultad;
    private CarreraCategoria carrera;
    private PeriodoCategoria periodo;
    private List<Respuesta> respuestas;

    public Alumno(FacultadCategoria facultad, CarreraCategoria carrera, PeriodoCategoria periodo, String cedula, String nombre, String apellido) {
        super(cedula, nombre, apellido);
        this.facultad = facultad;
        this.carrera = carrera;
        this.periodo = periodo;
        respuestas=new ArrayList <>();
    }

    public FacultadCategoria getFacultad() {
        return facultad;
    }

    public CarreraCategoria getCarrera() {
        return carrera;
    }

    public PeriodoCategoria getPeriodo() {
        return periodo;
    }

    public void agregarRespuesta(Respuesta respuesta){
        respuestas.add(respuesta);
        //System.out.println("respuestas cuantas hay: "+respuestas.size());
    }


    public Respuesta darUnaRespuesta(String nombre,int version){
        for(int i=0;i<respuestas.size();i++){
            if(respuestas.get(i).getNombre().equals(nombre)&&respuestas.get(i).getIntento()==version){
                return respuestas.get(i);
            }
        }
        return null;
    }

    public List<Respuesta> getRespuestas() {
        return respuestas;
    }



}