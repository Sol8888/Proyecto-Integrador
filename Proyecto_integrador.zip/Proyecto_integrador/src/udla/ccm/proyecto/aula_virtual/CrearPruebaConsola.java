package udla.ccm.proyecto.aula_virtual;


import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class CrearPruebaConsola {

    private Prueba prueba;
    private Clase clase;
    private int contadorPreguntas;
    private Validacion v = new Validacion();

    public CrearPruebaConsola(Prueba prueba, Clase clase) {
        this.prueba = prueba;
        this.clase = clase;
        contadorPreguntas = 1;
        System.out.println("Creacion versión: " + ConsolaLogin.control);
        previsualizarPrueba();
        System.out.println("Contador: " + contadorPreguntas);
    }

    private void previsualizarPrueba() {
        int count = 0;
        for (Pregunta pregunta : prueba.darVersion(ConsolaLogin.control).getListaPreguntas()) {
            System.out.println((count + 1) + ": " + pregunta.getEnunciado());
            count++;
        }
    }

    private void agregarPregunta() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Escriba la pregunta:");
        String enunciado = scanner.nextLine();

        System.out.println("Ingresar las 4 posibles respuestas:");
        List<String> opciones = new ArrayList<>();
        for (int i = 1; i <= 4; i++) {
            System.out.print(i + ": ");
            opciones.add(scanner.nextLine());
        }

        System.out.println("El numero de la respuesta correcta es (1-4): ");
        int respuestaCorrecta = scanner.nextInt();

        System.out.println("La puntuación de la pregunta: ");
        int puntuacion = scanner.nextInt();

        Pregunta pregunta = new Pregunta(enunciado, opciones, opciones.get(respuestaCorrecta - 1), puntuacion);
        prueba.anadirPregunta(ConsolaLogin.control, pregunta);
        previsualizarPrueba();
        System.out.println("Pregunta agregada correctamente");
        contadorPreguntas++;
    }

    public void ejecutar() {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("1. Agregar Pregunta");
            System.out.println("2. Finalizar Creacion de Versión");
            System.out.print("Seleccione una opción: ");

            int opcion = scanner.nextInt();

            switch (opcion) {
                case 1:
                    agregarPregunta();
                    break;
                case 2:
                    System.out.println("Finalizando Creacion de Versión");
                    return;
                default:
                    System.out.println("Opción no válida. Inténtelo de nuevo.");
            }
        }
    }

    public static void main(String[] args) {
        Prueba prueba = new Prueba();  // Debes ajustar la inicialización según tus necesidades.
        Clase clase = new Clase();  // Debes ajustar la inicialización según tus necesidades.

        CrearPruebaConsola creador = new CrearPruebaConsola(prueba, clase);
        creador.ejecutar();
    }
}

