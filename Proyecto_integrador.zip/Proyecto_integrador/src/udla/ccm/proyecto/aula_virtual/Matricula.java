package udla.ccm.proyecto.aula_virtual;

public class Matricula {

    private boolean estado;
    private Alumno alumno;
    private Clase clase;

    public Matricula(Alumno alumno, Clase clase) {
        this.alumno = alumno;
        this.clase = clase;
        estado=true;
    }


    public boolean isEstado() {
        return estado;
    }

    public Alumno getAlumno() {
        return alumno;
    }

    public Clase getClase() {
        return clase;
    }

}


