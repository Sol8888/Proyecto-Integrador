package udla.ccm.proyecto.aula_virtual;

public enum CarreraCategoria {
    RELACIONES_INTERNACIONALES,
    CIENCIAS_POLITICAS,
    DERECHO,
    ING_TELECOMUNICACIONES,
    ING_SOFTWARE,
    ING_CIBERSEGURIDAD,
    MEDICINA,
}
