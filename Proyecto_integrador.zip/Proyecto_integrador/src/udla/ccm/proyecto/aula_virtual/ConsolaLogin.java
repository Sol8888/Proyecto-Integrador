package udla.ccm.proyecto.aula_virtual;


import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ConsolaLogin {

    public static ArrayList<Usuario> usuarios = new ArrayList<>();
    public static ArrayList<Materia> materias = new ArrayList<>();
    public static ArrayList<Clase> clases = new ArrayList<>();
    public static ArrayList<Matricula> matriculas = new ArrayList<>();
    public static int control;
    public static int[] arregloControl = new int[100];
    public static Usuario usuarioActual;

    public ConsolaLogin(Usuario usuario) {
        usuarioActual = null;
    }

    public static void inicializarVersiones() {
        control = 0;
    }

    public static void cargarDatos() {
        // TODO: Agregar datos como en el código original
    }

    public static void main(String[] args) {
        cargarDatos();

        // Aquí inicia la simulación de inicio de sesión en consola
        Scanner scanner = new Scanner(System.in);

        System.out.print("Ingrese su usuario: ");
        String usuarioInput = scanner.nextLine();

        System.out.print("Ingrese su contraseña: ");
        String contraseniaInput = scanner.nextLine();

        boolean si = false;

        for (int i = 0; i < usuarios.size(); i++) {
            if (usuarios.get(i).getUsuario().equals(usuarioInput) && usuarios.get(i).getContrasenia().equals(contraseniaInput)) {
                if (usuarioActual instanceof Alumno) {
                    usuarioActual = (Alumno) usuarios.get(i);
                } else if (usuarioActual instanceof Profesor) {
                    usuarioActual = (Profesor) usuarios.get(i);
                } else {
                    usuarioActual = usuarios.get(i);
                }

                si = true;
                break;
            }
        }

        if (si) {
            System.out.println("Inicio de sesión exitoso.");

            if (usuarioActual instanceof Alumno) {
                System.out.println("Bienvenido, estudiante " + usuarioActual.getNombre());
                // TODO: Realizar acciones para estudiantes
            } else if (usuarioActual instanceof Profesor) {
                System.out.println("Bienvenido, profesor " + usuarioActual.getNombre());
                // TODO: Realizar acciones para profesores
            } else if (usuarioActual instanceof Usuario) {
                System.out.println("Bienvenido, usuario " + usuarioActual.getNombre());
                // TODO: Realizar acciones para usuarios
            }

            // Ejemplo de matriculación
            Clase claseEjemplo = clases.get(0);  // Seleccionar una clase de la lista
            Matricula nuevaMatricula = new Matricula((Alumno) usuarioActual, claseEjemplo);
            claseEjemplo.agregarMatricula(nuevaMatricula);
            matriculas.add(nuevaMatricula);
        } else {
            System.out.println("Verifique los datos ingresados, clave o contraseña incorrectos");
        }
    }
}
