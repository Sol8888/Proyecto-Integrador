package udla.ccm.proyecto.aula_virtual;

import java.util.ArrayList;
import java.util.List;
public class Respuesta {

    private BancoPregunta bancopregunta;
    private String nombre;
    private List<String> respuestas;
    private float calificacion;
    private int intento;

    public Respuesta(BancoPregunta bancopregunta, String nombre,int intento) {
        this.bancopregunta = bancopregunta;
        this.nombre = nombre;
        respuestas= new ArrayList<>();
        calificacion=0;
        this.intento=intento;
        //intentosDisponibles=0;
        llenarLista();

    }
    /**
     * LLena la lista para inicializar el string de respuestas
     */
    private void llenarLista(){
        int tamanio;
        tamanio=bancopregunta.getListaPreguntas().size();
        for(int i=0;i<=tamanio;i++){
            respuestas.add("0");
        }
    }
    /**
     *
     * @param respuesta recibe un string respuesta
     * @param posicion  recibe un entero posicion que sirve como indice de la lista respuestas
     */
    public void agregarRespuestaPosicion(String respuesta,int posicion)
    {
        respuestas.set(posicion,respuesta);
        System.out.println("arreglo"+respuestas.get(posicion));
    }

    /**
     *
     * @param bp recibe un objeto pregunta
     * @return un float con la calificacion
     */
    public float calificarPrueba(BancoPregunta bp){
        int tamanio;
        float resultado=0;
        //intentosDisponibles++;
        tamanio=bp.getListaPreguntas().size();System.out.println("tamanio preguntas"+tamanio);
        for(int i=0;i<tamanio;i++){
            System.out.println("primera parte: "+bp.obtenerPregunta(i).getCorrecta());
            System.out.println("segunda parte: "+respuestas.get(i));
            if(bp.obtenerPregunta(i).getCorrecta().equals(respuestas.get(i))){
                resultado=resultado+bancopregunta.obtenerPregunta(i).getPuntuacion();
                System.out.println("si se sumo bien"+i);
            }
        }
        return resultado;
    }
    /**
     *
     * @param resultado recibe un float resultado
     * @return un float con la calificacion sobre 10
     */
    public float sobreDiez(float resultado){

        float puntacionTotal=0;
        int tamanio;
        tamanio=bancopregunta.getListaPreguntas().size();
        for(int i=0;i<tamanio;i++){
            puntacionTotal= puntacionTotal +bancopregunta.obtenerPregunta(i).getPuntuacion();
        }
        return resultado*10/puntacionTotal;
    }

    public String getNombre() {
        return nombre;
    }

    public void setCalificacion(float calificacion) {
        this.calificacion = calificacion;
    }

    public float getCalificacion() {
        return calificacion;
    }

    public BancoPregunta getBancopregunta() {
        return bancopregunta;
    }

    public List<String> getRespuestas() {
        return respuestas;
    }

    public int getIntento() {
        return intento;
    }


}

