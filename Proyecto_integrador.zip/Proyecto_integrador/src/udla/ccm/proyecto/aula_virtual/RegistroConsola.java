package udla.ccm.proyecto.aula_virtual;

import java.util.Scanner;

public class RegistroConsola {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Registro de Alumnos");

        // Ingresar datos
        System.out.print("Nombre: ");
        String nombre = scanner.nextLine();

        System.out.print("Apellido: ");
        String apellido = scanner.nextLine();

        System.out.print("Cédula: ");
        String cedula = scanner.nextLine();

        // Validar datos
        boolean nombreValido = Validacion.validacionStrings(nombre);
        boolean apellidoValido = Validacion.validacionStrings(apellido);
        boolean cedulaValida = Validacion.validacionStrings(cedula);

        // Mostrar mensajes de error si es necesario
        if (!nombreValido || !apellidoValido) {
            System.out.println("Verifique los campos nombre y apellido.");
        }

        if (!cedulaValida) {
            System.out.println("La cédula no es válida.");
        }

        // Continuar con el registro si los datos son válidos
        if (nombreValido && apellidoValido && cedulaValida) {
            // Continuar con la lógica de registro aquí

            System.out.print("Facultad: ");
            String facultad = scanner.nextLine();
            FacultadCategoria facultadCategoria = FacultadCategoria.valueOf(facultad.toUpperCase());

            System.out.print("Carrera: ");
            String carrera = scanner.nextLine();
            CarreraCategoria carreraCategoria = CarreraCategoria.valueOf(carrera.toUpperCase());

            System.out.print("Período: ");
            String periodo = scanner.nextLine();
            PeriodoCategoria periodoCategoria = PeriodoCategoria.valueOf(periodo.toUpperCase());

                // Crear y registrar el alumno
                Alumno nuevoAlumno = new Alumno(facultadCategoria, carreraCategoria, periodoCategoria, cedula, nombre, apellido);
                listaAlumnos.add(nuevoAlumno);

                System.out.println("Alumno registrado correctamente.");


            scanner.close();
        }
    }

            System.out.println("Alumno registrado correctamente.");

        scanner.close();
    }
}

