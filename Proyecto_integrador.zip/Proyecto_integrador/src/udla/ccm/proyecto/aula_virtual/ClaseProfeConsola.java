package udla.ccm.proyecto.aula_virtual;

import java.util.ArrayList;
import java.util.Scanner;

public class ClaseProfeConsola {
    private Clase clase;
    private Prueba prueba;
    private Validador v = new Validador();

    public ClaseProfeConsola(Clase clase) {
        this.clase = clase;
    }

    public void ejecutar() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("BIENVENIDO PROFESOR");

        while (true) {
            System.out.println("1. Crear Prueba");
            System.out.println("2. Revisar Notas");
            System.out.println("3. Ver Pruebas Creadas");
            System.out.println("4. Salir");
            System.out.print("Seleccione una opción: ");

            int opcion = scanner.nextInt();

            switch (opcion) {
                case 1:
                    crearPrueba(scanner);
                    break;
                case 2:
                    revisarNotas(scanner);
                    break;
                case 3:
                    verPruebasCreadas();
                    break;
                case 4:
                    System.out.println("Hasta luego");
                    scanner.close();
                    System.exit(0);
                default:
                    System.out.println("Opción no válida. Intente de nuevo.");
                    break;
            }
        }
    }

    private void crearPrueba(Scanner scanner) {
        // Lógica de creación de prueba en consola
        System.out.println("Ingrese los datos de la prueba:");

        // ... (solicitar y validar datos de la prueba)

        // Simulación de agregar prueba a la clase
        clase.agregarPrueba(prueba);

        System.out.println("Prueba creada exitosamente.");
    }

    private void revisarNotas(Scanner scanner) {
        // Lógica de revisar notas en consola
        System.out.println("Ingrese el nombre del alumno:");
        String nombreAlumno = scanner.next();

        // ... (lógica para mostrar notas del alumno)
    }

    private void verPruebasCreadas() {
        // Lógica para mostrar las pruebas creadas en consola
        System.out.println("Pruebas Creadas:");
        for (Prueba p : clase.getPruebas()) {
            System.out.println(p);
        }
    }

    public static void main(String[] args) {
        // Crear una instancia de Clase (simulación de datos)
        Clase clase = new Clase();

        // Crear una instancia de ClaseProfeConsola y ejecutar el programa
        ClaseProfeConsola programa = new ClaseProfeConsola(clase);
        programa.ejecutar();
    }
}
