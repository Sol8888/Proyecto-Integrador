package udla.ccm.proyecto.aula_virtual;
import java.util.List;
public class Pregunta {
    private String enunciado;
    private List<String> listaOpciones;
    private String correcta;
    private float puntuacion;


    public Pregunta(String enunciado, List<String> listaOpciones, String correcta, float puntuacion) {
        this.enunciado = enunciado;
        this.listaOpciones = listaOpciones;
        this.correcta = correcta;
        this.puntuacion = puntuacion;

    }

    public String getEnunciado() {
        return enunciado;
    }

    public void setEnunciado(String enunciado) {
        this.enunciado = enunciado;
    }

    public List<String> getListaOpciones() {
        return listaOpciones;
    }

    public void setListaOpciones(List<String> listaOpciones) {
        this.listaOpciones = listaOpciones;
    }

    public String getCorrecta() {
        return correcta;
    }

    public void setCorrecta(String correcta) {
        this.correcta = correcta;
    }

    public float getPuntuacion() {
        return puntuacion;
    }

    public void setPuntuacion(float puntuacion) {
        this.puntuacion = puntuacion;
    }


    /*public String imprimirOpciones(){
        String acumulado1="";
         for(int i=0; i < listaOpciones.size();i++){
           acumulado1=acumulado1+"\n"+listaOpciones.get(i);
        }
         return acumulado1;
    }*/
    public String imprimirRespuesta(int i){
        return listaOpciones.get(i);
    }


    @Override
    public String toString() {
        return enunciado +"\n"+puntuacion+"\n";
    }

}
