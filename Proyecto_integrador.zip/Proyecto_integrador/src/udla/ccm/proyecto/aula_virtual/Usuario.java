package udla.ccm.proyecto.aula_virtual;

public class Usuario {
    private String nombre,apellido,usuario,contrasenia,cedula;
    //variable statica para control codigo
    private static int contador=0000;

    public Usuario(String cedula,String nombre, String apellido){
        this.cedula=cedula;
        this.nombre=nombre;
        this.apellido=apellido;
        this.usuario=cedula;
        this.contrasenia = "contrasenia123"+contador;
        contador++;

    }



    public String getNombre() {
        return nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public String getUsuario() {
        return usuario;
    }

    public String getContrasenia() {
        return contrasenia;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public void setContrasenia(String contrasenia) {
        this.contrasenia = contrasenia;
    }

    public String getCedula() {
        return cedula;
    }

    public static int getContador() {
        return contador;
    }


}

