package udla.ccm.proyecto.aula_virtual;

public class Materia {
    private String nombreMat,identificador;
    private PeriodoCategoria periodo;
    private FacultadCategoria facultad;
    private CarreraCategoria carrera;
    private static int contador=0000;

    public Materia(String nombreMat, String identificador, PeriodoCategoria periodo, FacultadCategoria facultad, CarreraCategoria carrera) {
        this.nombreMat = nombreMat;
        this.identificador = identificador;
        this.periodo = periodo;
        this.facultad = facultad;
        this.carrera = carrera;
    }

    public String getNombreMat() {
        return nombreMat;
    }

    public void setNombreMat(String nombreMat) {
        this.nombreMat = nombreMat;
    }


    public static int getContador() {
        return contador;
    }

    public String getIdentificador() {
        return identificador;
    }

    public PeriodoCategoria getPeriodo() {
        return periodo;
    }

    public FacultadCategoria getFacultad() {
        return facultad;
    }

    public CarreraCategoria getCarrera() {
        return carrera;
    }


}
