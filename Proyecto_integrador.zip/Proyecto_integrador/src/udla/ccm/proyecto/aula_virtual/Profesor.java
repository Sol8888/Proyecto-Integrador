package udla.ccm.proyecto.aula_virtual;

public class Profesor extends Usuario {
    private String titulo;

    public Profesor(String titulo, String cedula, String nombre, String apellido) {
        super(cedula, nombre, apellido);
        this.titulo = titulo;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }



}
