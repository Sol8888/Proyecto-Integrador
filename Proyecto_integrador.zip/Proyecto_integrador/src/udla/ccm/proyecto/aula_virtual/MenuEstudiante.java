package udla.ccm.proyecto.aula_virtual;



import java.util.ArrayList;
import java.util.Scanner;
import java.util.stream.Collectors;

public class MenuEstudiante {

    private Alumno alumno;

    public MenuEstudiante(Usuario usuario) {
        alumno = (Alumno) usuario;
        cargarMateriasConsola();
    }

    private void cargarMateriasConsola() {
        int count = 0;
        ArrayList<Matricula> matriculaAlumno = new ArrayList<>();
        matriculaAlumno = ConsolaLogin.matriculas.stream()
                .filter(matricula -> matricula.getAlumno().getCedula().equals(alumno.getCedula()))
                .collect(Collectors.toCollection(ArrayList::new));

        for (Matricula matricula : matriculaAlumno) {
            System.out.println(matricula.getClase().getIdentificador() + "\t" +
                    matricula.getClase().getMateria().getNombreMat() + "\t" +
                    (matricula.isEstado() ? "ACTIVO" : "DESACTIVADO"));
            count++;
        }
    }

    public void registrarClaseConsola(String codigo) {
        boolean validar = false;
        boolean validar1 = true;

        for (int i = 0; i < ConsolaLogin.clases.size(); i++) {
            Clase ac = ConsolaLogin.clases.get(i);
            if (ac.getCodigo().equals(codigo)) {
                if (ac.validarInscripcionUnica(alumno)) {
                    validar1 = false;
                } else {
                    if (ac.validarInscripcion(alumno)) {
                        Matricula matricula = new Matricula(alumno, ConsolaLogin.clases.get(i));
                        ConsolaLogin.matriculas.add(matricula);
                        ConsolaLogin.clases.get(i).agregarMatricula(matricula);
                        System.out.println("Matriculación realizada con éxito");
                        validar = true;
                        break;
                    }
                }
            }
        }
        if (validar1 == false) {
            System.out.println("No se puede volver a matricular a una clase");
        } else if (validar == false) {
            System.out.println("No se pudo realizar el proceso de inscripción. Compruebe que el código esté correcto o tenga los permisos para la inscripción");
        }

        cargarMateriasConsola();
    }

    public void tomarPruebasConsola() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Seleccione una fila para tomar las pruebas (ingrese el identificador de la clase):");

        if (scanner.hasNext()) {
            String identificador = scanner.next();
            ArrayList<Matricula> matriculaAlumno = new ArrayList<>();
            matriculaAlumno = ConsolaLogin.matriculas.stream()
                    .filter(matricula -> matricula.getAlumno().getCedula().equals(alumno.getCedula()))
                    .collect(Collectors.toCollection(ArrayList::new));

            for (Matricula matricula : matriculaAlumno) {
                if (matricula.isEstado()) {
                    if (matricula.getClase().getIdentificador().equals(identificador)) {
                        Matricula matricula1 = matricula;
                        // Agrega la lógica para tomar las pruebas en la consola
                        System.out.println("Tomando pruebas para la clase con identificador: " + matricula.getClase().getIdentificador());
                    }
                } else {
                    System.out.println("Clase inactiva por desmatriculación");
                }
            }
        }
    }
}

