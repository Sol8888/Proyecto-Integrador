import udla.ccm.proyecto.aula_virtual.*;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        // Supongamos que ya tienes instancias de Usuario, Profesor, Materia, Clase, etc.
        // Necesitarás crear esos objetos y las relaciones entre ellos antes de ejecutar esta parte.

        // Ejemplo de creación de instancias
        Usuario alumno = new Alumno();
        Materia materia = new Materia();
        Profesor profesor = new Profesor();
        Clase clase = new Clase();
        Matricula matricula = new Matricula(alumno, clase);

        // Crear la instancia de la versión de consola
        ClaseEstudianteConsole consola = new ClaseEstudianteConsole(matricula);

        // Ejecutar la lógica de consola
        consola.ejecutar();
    }
}